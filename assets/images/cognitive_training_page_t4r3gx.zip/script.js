// Aquí puedes agregar cualquier funcionalidad adicional en JavaScript
